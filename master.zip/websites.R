# This script opens all the URLS that I will need
# to link to during the workshop

# is most research wrong
browseURL('https://www.youtube.com/watch?v=42QuXLucH3Q')

# Repo for this course
browseURL('https://github.com/AugustT/reproducibility_masterclass')

# R markdown on Rstudio
browseURL('https://rmarkdown.rstudio.com/lesson-2.html')

# R markdown on Coding club
browseURL('https://ourcodingclub.github.io/2016/11/24/rmarkdown-1.html')

# Repo commit history
browseURL('https://github.com/AugustT/reproducibility_masterclass/commits/master')

# Coding club Github practical
browseURL('https://ourcodingclub.github.io/2017/02/27/git.html')

# Gallery of shiny applications
browseURL('https://shiny.rstudio.com/gallery/')
