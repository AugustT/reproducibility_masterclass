# Code for getting the course materials set up
install.packages('usethis')
usethis::use_course('https://github.com/AugustT/reproducibility_masterclass/raw/master/master.zip')