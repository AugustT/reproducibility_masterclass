# Steve asked me to average some numbers

x <- c(5, 6, 8, 9, 2, 4, 5,
       2, 5, 6, 3, 6, 5)

plot(x)

mean(x)